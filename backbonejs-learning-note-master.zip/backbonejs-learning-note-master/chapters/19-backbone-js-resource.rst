Backbonejs相关资源
===============================

这次没有参考太多资源，主要还是官方的东西：

官网：
http://backbonejs.org/

能让你大概认识backbone.js是什么以及怎么用的网站：
http://backbonetutorials.com/

源码：
https://github.com/jashkenas/backbone/blob/master/backbone.js

todos代码：
http://backbonejs.org/examples/todos/index.html

另外还有几篇中文的博客也不错：
http://weakfi.iteye.com/blog/1391990

http://blog.csdn.net/soasme/article/details/6581029

http://www.cnblogs.com/nuysoft/archive/2012/03/19/2404274.html

当你对这个东西有一个感觉之后，去看最本质的东西才是王道！
